import requests
import sys  # Para forçar a atualização da tela

# Mapeamento do Sistema Fonético Major
major_system_mapping = {
    "0": ["z", "s", "ss", "ç","c"],
    "1": ["d", "t"],
    "2": ["n", "nh"],
    "3": ["m"],
    "4": ["r", "rr"],  # "rr" é agora parte do algarismo 4
    "5": ["l"],
    "6": ["j", "sc", "x", "ch", "g", "ge", "gi"],
    "7": ["q", "c", "g"],  # "g" será tratado separadamente
    "8": ["f", "v"],
    "9": ["p", "b"]
}

# Inverso do mapeamento
inverse_mapping = {v: k for k, vs in major_system_mapping.items() for v in vs}

# Função para converter uma palavra em um número pelo sistema fonético Major
def word_to_major_number(word):
    number = ""
    word = word.lower()
    i = 0
    while i < len(word):
        # Verificar se encontramos "rr", para tratar como "4"
        if i + 1 < len(word) and word[i] == "r" and word[i + 1] == "r":
            number += "4"
            i += 2  # Pular o próximo "r"
        # Verificar se encontramos "ch", para tratar como "6"
        elif i + 1 < len(word) and word[i] == "c" and word[i + 1] == "h":
            number += "6"
            i += 2  # Pular o "h"
        # Verificar se "c" é seguido de "e" ou "i", para tratá-lo como "0"
        elif word[i] == "c" and (i + 1 < len(word) and word[i + 1] in "ei"):
            number += "0"
            i += 2  # Pular o próximo "e" ou "i"
        # Verificar se "g" é seguido de "e" ou "i", para tratá-lo como "6"
        elif word[i] == "g" and (i + 1 < len(word) and word[i + 1] in "ei"):
            number += "6"
            i += 2  # Pular o próximo "e" ou "i"
        # Verificar se "g" é seguido de "a", "o" ou "u", para tratá-lo como "7"
        elif word[i] == "g" and (i + 1 < len(word) and word[i + 1] in "aou"):
            number += "7"
            i += 2  # Pular o próximo "a", "o" ou "u"
        elif word[i] in inverse_mapping:
            number += inverse_mapping[word[i]]
            i += 1
        else:
            i += 1  # Pular letras que não fazem parte do mapeamento
    return number


# Função para gerar combinações de vogais entre consoantes
def generate_vowel_combinations(consonants):
    vowels = ["a", "e", "i", "o", "u"]
    combinations = []

    # Combinações com vogais antes, no meio e depois das consoantes
    for v1 in vowels:
        combinations.append(f"{v1}{consonants[0]}{consonants[1]}")
        for v2 in vowels:
            combinations.append(f"{v1}{consonants[0]}{v2}{consonants[1]}")

    # Combinações de vogal no meio (por exemplo, imp, inc)
    for v1 in vowels:
        combinations.append(f"{consonants[0]}{v1}{consonants[1]}")
        for v2 in vowels:
            combinations.append(f"{consonants[0]}{v1}{v2}{consonants[1]}")

    # Combinações com vogal no final
    for v1 in vowels:
        combinations.append(f"{consonants[0]}{consonants[1]}{v1}")
        for v2 in vowels:
            combinations.append(f"{consonants[0]}{v2}{consonants[1]}{v1}")

    return combinations

# Função para gerar combinações de vogais especiais (duas vogais diferentes)
def generate_special_vowel_combinations(consonant):
    special_vowels = ["ae", "ai", "ao", "au", "ea", "ei", "eo", "eu", "ia", "ie", "io", "iu", "oa", "oe", "oi", "ou", "ua", "ue", "ui", "uo"]
    combinations = []
    for v in special_vowels:
        combinations.append(f"{consonant}{v}")  # Cruzando a primeira consoante com as vogais especiais
    return combinations

# Função para buscar palavras na API
def fetch_words_from_api(query, search_type):
    url = f"https://api.dicionario-aberto.net/{search_type}/{query}"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            return response.json() if isinstance(response.json(), list) else []
    except Exception as e:
        print(f"Erro ao buscar {query}: {e}")
    return []

# Função para encontrar palavras por número
def find_words_by_number(number):
    if len(number) < 2:
        print("O número deve ter pelo menos dois dígitos.")
        return []

    # Primeiro e segundo dígitos do número
    prefix_digits = number[:2]
    consonant_options = [major_system_mapping[d] for d in prefix_digits]

    print(f"Buscando palavras para o número {number}...")
    found_words = set()
    searched_combinations = set()  # Para evitar pesquisa repetida de combinações

    # Gerar as combinações de vogais com a primeira consoante (do número convertido)
    for c1 in consonant_options[0]:
        for c2 in consonant_options[1]:
            infix_suffix_combinations = generate_vowel_combinations([c1, c2])
            for query in infix_suffix_combinations:
                if query not in searched_combinations and len(query) == 3:  # Garantir que a combinação tenha exatamente 3 letras
                    searched_combinations.add(query)

                    # Pesquisa por prefixo e infixo
                    prefix_results = fetch_words_from_api(query, "prefix")
                    infix_results = fetch_words_from_api(query, "infix")

                    # Unir resultados e garantir que palavras sejam únicas
                    all_results = {word_data.get("word", "") for word_data in prefix_results + infix_results}
                    for word in all_results:
                        if word:  # Verificar se a palavra não está vazia
                            converted_number = word_to_major_number(word)
                            if converted_number == number:  # Apenas adiciona palavras com o número exato
                                found_words.add((word, query))  # Armazenando a palavra e a combinação usada
                                # Exibindo imediatamente a palavra encontrada
                                print(f"Palavra encontrada: {word}")
                                sys.stdout.flush()  # Força a atualização da tela

    # Gerar as combinações com vogais especiais e a primeira consoante
    special_combinations = generate_special_vowel_combinations(consonant_options[0][0])  # Apenas a primeira consoante
    for query in special_combinations:
        if query not in searched_combinations and len(query) <= 3:  # Garantir que a combinação tenha no máximo 3 letras
            searched_combinations.add(query)

            # Pesquisa por prefixo e infixo
            prefix_results = fetch_words_from_api(query, "prefix")
            infix_results = fetch_words_from_api(query, "infix")

            # Unir resultados e garantir que palavras sejam únicas
            all_results = {word_data.get("word", "") for word_data in prefix_results + infix_results}
            for word in all_results:
                if word:  # Verificar se a palavra não está vazia
                    converted_number = word_to_major_number(word)
                    if converted_number == number:  # Apenas adiciona palavras com o número exato
                        found_words.add((word, query))  # Armazenando a palavra e a combinação usada
                        # Exibindo imediatamente a palavra encontrada
                        print(f"Palavra encontrada: {word}")
                        sys.stdout.flush()  # Força a atualização da tela

    if not found_words:
        print("Nenhuma palavra válida encontrada.")
    else:
        print("\nBusca concluída.")

    return list(found_words)

# Interação principal
def main():
    while True:
        user_input = input("Insira um número para gerar palavras (ou 'sair'): ")
        if user_input.lower() == 'sair':
            break
        if not user_input.isdigit():
            print("Por favor, insira apenas números.")
            continue

        print(f"\nPalavras sugeridas para {user_input}:")
        find_words_by_number(user_input)

if __name__ == "__main__":
    main()
